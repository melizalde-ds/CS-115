/**
* File: REO.java
* Description: This class is the main class that runs the program. It has a menu that allows the user to navigate through the program.
* Lessons Learned: It helped me review the main class
* Instructor's Name: Barbara Chamberlin
*
* @author: Miguel Elizalde
* @since: 11/11/2023
*/
package RealEstate;

import java.util.Scanner;

public class REO {
    public static void main(String[] args) {
        Scanner sIn = new Scanner(System.in);
        boolean close = false;
        boolean done = false;
        while (!close) {
            System.out.println("-----------------------------------------");
            System.out.printf("%25s\n", "Main Menu");
            System.out.println("-----------------------------------------");
            System.out.println("1: Listings");
            System.out.println("2: Bids");
            System.out.println("What would you like to do? (1-2):");
            String input = sIn.nextLine();
            try {
                int choice = Integer.parseInt(input);
                switch (choice) {
                    case 1:
                        listings();
                        break;
                    case 2:
                        bids();
                        break;
                    default:
                        System.out.println("Invalid input. Please enter a number between 1 and 2");
                        break;
                }
            } catch (NumberFormatException e) {
                System.out.println("Invalid input. Please enter a number between 1 and 2");
            }
        }
    }

    private static void listings() {
        Scanner sIn = new Scanner(System.in);
        boolean close = false;
        while (!close) {
            System.out.println("-----------------------------------------");
            System.out.printf("%25s\n", "Listing Menu");
            System.out.println("-----------------------------------------");
            System.out.println("1: Add Listing");
            System.out.println("2: Show Listings");
            System.out.println("3: Auto Populate Listings (Dev Tool)");
            System.out.println("ENTER: Exit back to the previous menu");
            System.out.println("What would you like to do? (1-3):");
            String input = sIn.nextLine();
            if (input.equals("")) {
                close = true;
            } else {
                try {
                    int choice = Integer.parseInt(input);
                    switch (choice) {
                        case 1:
                            addListing();
                            break;
                        case 2:
                            break;
                        case 3:
                            break;
                        default:
                            System.out.println("Invalid input. Please enter a number between 1 and 3");
                            break;
                    }
                } catch (NumberFormatException e) {
                    System.out.println("Invalid input. Please enter a number between 1 and 3");
                }
            }
        }
    }

    private static void addListing() {
        Scanner sIn = new Scanner(System.in);
        boolean close = false;
        while (!close) {
            System.out.println("-----------------------------------------");
            System.out.printf("%25s\n", "Add Listing Menu");
            System.out.println("-----------------------------------------");
            System.out.println("1: Add House");
            System.out.println("2: Add Condo");
            System.out.println("ENTER: Exit back to the previous menu");
            System.out.println("What would you like to do? (1-2):");
            String input = sIn.nextLine();
            if (input.equals("")) {
                close = true;
            } else {
                try {
                    int choice = Integer.parseInt(input);
                    switch (choice) {
                        case 1:
                            break;
                        case 2:
                            break;
                        case 3:
                            break;
                        default:
                            System.out.println("Invalid input. Please enter a number between 1 and 2");
                            break;
                    }
                } catch (NumberFormatException e) {
                    System.out.println("Invalid input. Please enter a number between 1 and 2");
                }
            }
        }
    }

    private static void bids() {
        Scanner sIn = new Scanner(System.in);
        boolean close = false;
        while (!close) {
            System.out.println("-----------------------------------------");
            System.out.printf("%25s\n", "Bids Menu");
            System.out.println("-----------------------------------------");
            System.out.println("1: Add New Bid");
            System.out.println("2: Show Existing Bids");
            System.out.println("3: Auto Populate Bids (Dev Tool)");
            System.out.println("ENTER: Exit back to the previous menu");
            System.out.println("What would you like to do? (1-3):");
            String input = sIn.nextLine();
            if (input.equals("")) {
                close = true;
            } else {
                try {
                    int choice = Integer.parseInt(input);
                    switch (choice) {
                        case 1:
                            break;
                        case 2:
                            break;
                        case 3:
                            break;
                        default:
                            System.out.println("Invalid input. Please enter a number between 1 and 3");
                            break;
                    }
                } catch (NumberFormatException e) {
                    System.out.println("Invalid input. Please enter a number between 1 and 3");
                }
            }
        }
    }
}
