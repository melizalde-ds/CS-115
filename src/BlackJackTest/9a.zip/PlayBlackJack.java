package BlackJackTest;

import BlackJackBase.PCard;
import BlackJack.BJCard;

public class PlayBlackJack {
    public static void main(String[] args) {
        PCard card = new BJCard("ACE", "HEART");
        card.showCard();
        CardTest.run(card);
    }
}
